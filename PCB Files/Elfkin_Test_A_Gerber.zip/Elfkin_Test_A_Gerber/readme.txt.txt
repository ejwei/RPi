Name: Eric Wei
Company Name: Empath Interactive

Job: 1031-1 
ELFKIN TEST BOARD REV A


The following files are required for this job:
Elfkin_Test_A.CMP Component Side Copper (Top)
Elfkin_Test_A.SOL Solder Side Copper (Bottom)
Elfkin_Test_A.STC Component Side SolderMask includes 10 mill board outline (Top Solder Mask)
Elfkin_Test_A.STS Solder Side Solder Mask (Bottom Solder Mask)
Elfkin_Test_A.PLC Top Silkscreen
ELFKIN_TEST_A.PDF Fabrication Drawing With Overall Dimensions and Mounting Hole Locations
readme.txt This file


Note: the Gerber files include embedded aperture data.

Drill Information

Drills used:

 Code  Size       used

 T01   0.0240inch   144
 T02   0.0315inch    90
 T03   0.0320inch   119
 T04   0.0394inch    52
 T05   0.0400inch    15
 T06   0.1180inch     2
 T07   0.1260inch     5

Total number of drills: 427


The board is approximately 100 mm x 80 mm, double-side,
..0625" nominal thickness, FR-4 material
1 oz or greater copper
All Holes are Standard through-hole plating, standard tin-lead plating on exposed
copper.

Solder mask both sides
=============================
